<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_BitwiseXor');

if (\false) {
    class BitwiseXorBinary extends \Twig_Node_Expression_Binary_BitwiseXor
    {
    }
}
