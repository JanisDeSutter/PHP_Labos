<?php

namespace Twig\Node;

class_exists('Twig_Node_Body');

if (\false) {
    class BodyNode extends \Twig_Node_Body
    {
    }
}
