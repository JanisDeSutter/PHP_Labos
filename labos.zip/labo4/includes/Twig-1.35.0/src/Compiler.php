<?php

namespace Twig;

class_exists('Twig_Compiler');

if (\false) {
    class Compiler extends \Twig_Compiler
    {
    }
}
