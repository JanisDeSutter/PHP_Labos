<?php

namespace Twig\Loader;

class_exists('Twig_Loader_Array');

if (\false) {
    class ArrayLoader extends \Twig_Loader_Array
    {
    }
}
