<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Sandbox');

if (\false) {
    class SandboxExtension extends \Twig_Extension_Sandbox
    {
    }
}
