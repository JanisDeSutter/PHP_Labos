<?php

namespace Twig\NodeVisitor;

class_exists('Twig_NodeVisitor_Optimizer');

if (\false) {
    class OptimizerNodeVisitor extends \Twig_NodeVisitor_Optimizer
    {
    }
}
