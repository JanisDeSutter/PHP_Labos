<?php

$firstName = 'Janis';
$lastName = 'DeSutter';
echo 'Hello World' . PHP_EOL;
echo 'It’s raining outside' . PHP_EOL;
echo 'The value of $firstName is ' . $firstName . ' The value of $lastName is' . $lastName . PHP_EOL;



