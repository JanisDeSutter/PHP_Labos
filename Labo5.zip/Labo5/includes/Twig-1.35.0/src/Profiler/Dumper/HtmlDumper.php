<?php

namespace Twig\Profiler\Dumper;

class_exists('Twig_Profiler_Dumper_Html');

if (\false) {
    class HtmlDumper extends \Twig_Profiler_Dumper_Html
    {
    }
}
