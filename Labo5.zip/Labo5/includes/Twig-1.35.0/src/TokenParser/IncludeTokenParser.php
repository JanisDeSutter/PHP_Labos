<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Include');

if (\false) {
    class IncludeTokenParser extends \Twig_TokenParser_Include
    {
    }
}
