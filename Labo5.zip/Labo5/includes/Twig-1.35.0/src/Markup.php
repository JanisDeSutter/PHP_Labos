<?php

namespace Twig;

class_exists('Twig_Markup');

if (\false) {
    class Markup extends \Twig_Markup
    {
    }
}
