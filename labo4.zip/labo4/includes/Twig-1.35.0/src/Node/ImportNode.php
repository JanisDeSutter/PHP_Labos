<?php

namespace Twig\Node;

class_exists('Twig_Node_Import');

if (\false) {
    class ImportNode extends \Twig_Node_Import
    {
    }
}
