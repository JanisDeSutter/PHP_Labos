<?php

namespace Twig\Node;

class_exists('Twig_NodeOutputInterface');

if (\false) {
    interface NodeOutputInterface extends \Twig_NodeOutputInterface
    {
    }
}
