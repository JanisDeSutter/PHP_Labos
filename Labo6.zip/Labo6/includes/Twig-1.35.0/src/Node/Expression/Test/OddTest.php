<?php

namespace Twig\Node\Expression\Test;

class_exists('Twig_Node_Expression_Test_Odd');

if (\false) {
    class OddTest extends \Twig_Node_Expression_Test_Odd
    {
    }
}
