<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_LessEqual');

if (\false) {
    class LessEqualBinary extends \Twig_Node_Expression_Binary_LessEqual
    {
    }
}
