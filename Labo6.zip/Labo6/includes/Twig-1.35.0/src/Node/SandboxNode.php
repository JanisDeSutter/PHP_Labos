<?php

namespace Twig\Node;

class_exists('Twig_Node_Sandbox');

if (\false) {
    class SandboxNode extends \Twig_Node_Sandbox
    {
    }
}
