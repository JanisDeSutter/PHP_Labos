<?php

namespace Twig\Node;

class_exists('Twig_Node_Set');

if (\false) {
    class SetNode extends \Twig_Node_Set
    {
    }
}
