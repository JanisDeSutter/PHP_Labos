<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_AutoEscape');

if (\false) {
    class AutoEscapeTokenParser extends \Twig_TokenParser_AutoEscape
    {
    }
}
